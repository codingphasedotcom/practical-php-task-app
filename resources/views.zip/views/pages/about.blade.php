@extends('layouts/app')

@section('title', 'Task Manager - About')


@section('content')
 <h1>About</h1>
@endsection
